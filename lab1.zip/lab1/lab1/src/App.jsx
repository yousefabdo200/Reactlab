import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import { StrictMode } from 'react'
import './index.css'
import Cart from './components/Cart'
function App() {
  const [count, setCount] = useState(0)
  const [items,setItems]=useState([{id:1,name:'burger',count:0},{id:2,name:'water',count:0},{id:3,name:'potato',count:0}])
  const handleIncrement=(id)=>{
    const newitems=[...items]
    const i= newitems.findIndex((item)=>item.id===id)
    newitems[i]={...newitems[i]}
    newitems[i].count= newitems[i].count+1
    setItems(newitems);
  }
  const handleDecrement=(id)=>{
    const newitems=[...items]
    const i= newitems.findIndex((item)=>item.id===id)
    newitems[i]={...newitems[i]}
    if( newitems[i].count>0)
      newitems[i].count= newitems[i].count-1
    setItems(newitems);
  }
  const handleDelete=(id)=>{
    const newItems = items.filter(item => item.id !== id);
    setItems(newItems);
  }
  const handleReset=()=>{
    const newitems=items.map(item=>({...item,count:0}))
    setItems(newitems)
  }
  return (<>
    {items.map(item=>(
      <Cart
      id={item.id}
      name={item.name}
      count={item.count}
      handleIncrement={handleIncrement}
      handleDecrement={handleDecrement}
      handleDelete={handleDelete}
      />
    ))}
    <button onClick={handleReset} className="bg-stone-400 w-25">reset</button>
    </>
  )

}

export default App
