function Cart(probs) {
    return <div className="flex gap-4 p-2 "><p className="bg-gray-50 w-25 text-center">{probs.name}</p> <p className="w-10 bg-gray-100  text-center" >{probs.count}</p>
      <button onClick={() => probs.handleIncrement(probs.id)} className="bg-blue-200 w-25">+</button>
      <button onClick={() => probs.handleDecrement(probs.id)} className="bg-gray-200 w-25">-</button>
      <button onClick={() =>probs.handleDelete(probs.id)} className="bg-red-600 w-25">delete</button>
    </div>;
}

export default Cart;
